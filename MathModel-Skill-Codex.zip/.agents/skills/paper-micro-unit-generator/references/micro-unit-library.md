# Legacy Micro-Unit Template Library

This reference preserves the original detailed CUMCM micro-unit handbook and its 200+ prompt templates. Use the template catalog only for a queued local repair or explicit legacy/quickstart scaffolding. Historical workflow and output-path instructions below are retained for context but are superseded by the parent `SKILL.md`; they must not produce formal filenames or replace the Standard 2.2 authoring flow.

# Historical Handbook

## 全局流程协作约束（长对话防漂移）

- 本 skill 不得作为孤立入口。用户要求完整论文、生成 Word、继续流程或不确定阶段时，先回到 `paper-workflow-orchestrator` 判断当前 S0-S8 阶段。
- 启动或继续本 skill 的正式任务前，必须运行：
  ```bash
  python .agents/skills/paper-workflow-orchestrator/scripts/workflow_guard.py --skill paper-micro-unit-generator
  ```
- 如果输出 `[WORKFLOW FAIL]` 或报告 `status != "PASS"`，停止本 skill，按 `paper_output/qa/workflow_guard_report.json` 的失败项回补前置阶段，不得凭记忆继续。
- 本 skill 只写入自己契约范围内的 `paper_output/` 产物；完成后必须回到 `paper-workflow-orchestrator` 判断下一步，并用 `context-memory-keeper` 记录已完成产物、阻塞项和下一步。
- 长对话中如果上下文变长、阶段不确定或用户分开调用 skill，先运行：
  ```bash
  python .agents/skills/paper-workflow-orchestrator/scripts/workflow_guard.py --status
  ```
  再读取 `paper_output/qa/workflow_guard_report.json`、`paper_output/preflight_report.json`、`paper_output/input_manifest.json`、`paper_output/results/run_manifest.json` 和本 skill 的上游 JSON 契约，按报告里的 `recommended_skill` 与 `next_action` 继续。
- 继续流程前，必须把 `paper_output/context/workflow_memory.json` 视为长期断点记录；若其中的 `current_step`、`next_step`、`recommended_skill` 与 `workflow_guard.py --status` 不一致，以 guard 报告为准。
- 每次完成本 skill 的产物后，先回到 `paper-workflow-orchestrator` 或运行 `workflow_guard.py --status`，再更新 workflow memory：
  ```bash
  python .agents/skills/context-memory-keeper/scripts/update_workflow_memory.py
  ```
  更新后读取 `paper_output/context/workflow_memory.json` / `.md`，确认下一步和推荐 skill 已记录。

## 执行契约
- 上游输入：必须读取 `paper_output/tasks.json`；可参考 `paper_output/plan/model_route.json`、`rubric_alignment.json`、`data_plan.json`、`visualization_plan.json`、`paper_output/figure_index.json`、`paper_output/results/` 与 `paper_output/tables/table_index.json`。
- 可输出：`paper_output/micro_units/*.txt`、`paper_output/generate_log.json`、`paper_output/final_paper.md`、`paper_output/ref_check.md` 与 `paper_output/final_paper.docx`。
- 下游交接：合并后的 `final_paper.md` 和 `final_paper.docx` 是验证草稿或局部写作素材；正式论文必须由 Agent 读取完整证据链后全局改写或重写，并再次调用 `quality-assurance-auditor`。
- 推荐下一步：合并完成后进入 `quality-assurance-auditor` 做最终一致性检查；完整论文目标应回到 `paper-workflow-orchestrator` 汇总产物。
- 失败回退：若 `tasks.json` 缺失，先运行 `quality-assurance-auditor`；若图表或结果契约尚未生成，正文只能生成通用草稿，并在 QA warning 或 `ref_check.md` 中提示真实结果待补。

## 目标
- 保留并组织 CUMCM 风格的高质量长文提示词资产，包括章节拆解、段落/句级写作模板、评分点覆盖和交叉引用要求。
- 配合 `scripts/generate_all_offline.py` 与 `scripts/merge.py`，可自动完成：微单元生成 → 合并 → 编号与交叉引用检查，生成 quickstart 验证草稿或低能力模型兜底草稿。
- 正式论文不应机械拼接微单元。Agent 应把本技能作为提示词资产库、结构辅助器和局部重写来源，在证据门禁通过后进行全局写作。
- 正式论文主写、`1 / 1.1 / 1.1.1` 范式约束、按子问题数量动态生成的篇幅门禁、原生公式和正式 Word 排版由 `paper-formal-writer` 负责，本技能不再承担正式论文主笔或正式 Word 排版职责。
- `scripts/generate_all_offline.py` 是离线样板生成器：可读取 `tasks.json`、`step3_filled_placeholder.py` 和结果证据，把当前赛题的信息填入草稿。它必须输出自然论文段落，不应把微单元编号写进正文，也不应替代正式主笔。

## 适用时机
- 用户已经明确采用 CUMCM 风格的细粒度拆分模板，希望把一篇大论文拆成大量小片段，逐步生成并自动合并时。
- 已经有题意对齐与模型路线（例如来自 `problem-doc-model-selector`），并且完成了数据计算与占位符填充，下一步需要系统地“写完所有文字”的场景。

## 脚本清单（本技能实际会用到的）
- `scripts/generate_all_offline.py`
  - 何时用：已有 `paper_output/tasks.json`，需要批量产出微单元文本文件时。
  - 做什么：生成 `paper_output/micro_units/*.txt` 和 `paper_output/generate_log.json`；每个文件是正式正文段落草稿，不带 `【章节 | 编号】` 这类过程标签。
- `scripts/merge.py`
  - 何时用：微单元已生成（或部分生成），需要合并成一份可读的论文草稿时。
  - 做什么：清理历史微单元过程标签，按章节合并，生成 `paper_output/final_paper.md`、`paper_output/final_paper.docx` 和 `paper_output/ref_check.md`。

## 输入
- 必填：
  - 任务清单：`paper_output/tasks.json`（由 `quality-assurance-auditor/scripts/pipeline.py` 生成）。
- 可选：
  - 占位符字典：`step3_filled_placeholder.py` 中的 `PLACEHOLDER`，用于把题目、模型名、结果数值写进正文。
  - 题意对齐结果与模型路线：`paper_output/step1/problem_analysis.json`、`paper_output/plan/model_route.json`、`paper_output/plan/rubric_alignment.json`，用于指导每个微单元的写作侧重点与交叉引用。
  - 数据与图表证据链：`paper_output/plan/data_plan.json`、`visualization_plan.json`、`paper_output/figure_index.json`，用于提醒正文里的图表、数据来源和输出路径要可追溯。
  - 结果与表格证据链：优先通过 `tasks.json` 读取 `result_summary`、`key_metrics`、`tables`、`conclusions`、`evidence_status`，这些字段通常由 QA 从 `paper_output/results/` 与 `paper_output/tables/table_index.json` 写入。
  - 若要接入大模型生成，可在此技能脚本基础上扩展生成逻辑。

## 输出
- 单元级输出：
  - `paper_output/micro_units/*.txt`：每个微单元对应一个文本文件，文件名包含编号（如 `ABS-1.txt`）。
  - `paper_output/generate_log.json`：记录每个单元的生成长度与输出路径。
- 文档级输出：
  - `paper_output/final_paper.md`：按任务清单顺序合并后的完整论文草稿。
  - `paper_output/ref_check.md`：交叉引用与编号检查报告。

## 目录约定（与项目全局对齐）
- 赛题与附件：`problem_files/`（由 QA 检查是否为空）。
- 本技能只读 `paper_output/tasks.json`，并写入 `paper_output/`。

## 前后衔接
- 前置：`quality-assurance-auditor`（先生成 `paper_output/tasks.json`）。
- 后续：若只是 quickstart 或兜底草稿，可回到 `quality-assurance-auditor` 做一致性检查；若要正式比赛稿，必须进入 `paper-formal-writer`。
- 若想继续到完整论文流程：回到 `paper-workflow-orchestrator`。

## 约束（必须遵守）

- **Memory Interaction (必做)**:
  - **开始生成前**：建议读取 `context-memory-keeper` 以获取最新的全局约束与风格要求；**特别注意**检查 `External Resources / Literature`，确保引用的文献与 memory 中的记录一致。
  - **合并完成后**：必须调用 `context-memory-keeper`，更新项目进度为“论文草稿已生成”，并记录 `final_paper.md` 的路径。
- 运行前必须满足：`paper_output/tasks.json` 已存在且可读；否则必须先调用 `quality-assurance-auditor`。
- 若 `tasks.json` 中已经包含 `main_model`、`model_reason`、`validation_plan`、`figure_suggestions`、`planned_figures`、`rubric_points`、`result_summary`、`key_metrics`、`tables`、`conclusions` 等字段，正文生成必须优先遵守这些模型路线、评分证据和结果证据，不得脱离契约自行发挥。
- 微单元编号只用于文件名、日志和局部重跑，不得作为正文标题写入最终稿；最终稿只保留章节标题和自然段。
- 原附录 A 的 200+ 微单元提示词是本项目核心提示词资产，必须保留。正式写作时可以按需引用这些提示词，但不能机械逐段拼接成低质量正文。
- 离线草稿应尽量接近 `tasks.json` 中的 `target_words`，避免每个微单元只生成一句任务式短句。
- 合并输出以 `paper_output/final_paper.md` 为唯一权威合并稿；不要在根目录或其他目录另起“final_paper.md”，避免引用混乱。
- 若用户目标是“论文生产完整”，本技能完成后必须确认 `paper_output/final_paper.md` 与 `paper_output/ref_check.md` 同时存在；若 `ref_check.md` 报断链，则视为未完成，需要修复后重跑合并。

## 工作流程

### 1. 准备微单元模板与占位符
- 从本文件“附录 A：扩展材料”中的 CUMCM 微单元提示词读取：
  - 论文整体拆分方案：每一章/节/段/句对应的微单元编号、角色、输入占位符、目标字数、验收标准与交叉引用要求。
  - 特别关注摘要、问题重述、模型建立与求解、结果分析与模型检验等评分权重高的部分，确保这些微单元的模板与验收要求更严格。
- 将题目、模型、算法、数值结果等关键信息填入占位符字典，以便在生成时统一替换。

### 2. 单元级生成策略
- 生成逻辑：
  - 按微单元编号顺序（如 `ABS-1-1`、`ABS-1-2`、`BG-1-1` 等）依次调用大模型，传入：
    - 对应行的角色设定、输入占位符、目标字数与验收标准。
    - 相关的题意对齐与模型路线信息（例如该句属于问题一/问题二/问题三的哪一部分，是否需要提及题目核心模型、算法或指标关键词）。
  - 模型输出后，立即进行本地校验：
    - 字数是否在要求范围内（例如 15–20 字）。
    - 是否包含指定关键词或符号（如题目背景词、核心模型名、关键指标单位等）。
    - 是否符合语法与风格要求（如被动语态、学术表达、引用格式）。
- 通过校验的单元写入 `paper_output/micro_units/`，未通过的单元记录失败原因以便重试。

### 3. 批量生成脚本协同
- `scripts/generate_all_offline.py`：
  - 读取 `paper_output/tasks.json`，逐微单元生成离线文本并写入 `paper_output/micro_units/*.txt`。
  - 每个微单元应生成可直接进入论文的自然段，围绕任务类型、主模型、验证计划、图表建议和结果证据展开，不输出任务编号标签。
- 本技能在被调用时，指导如何配置与调用这些脚本，解释每个参数的含义与对最终论文风格/长度的影响。

### 4. 合并与自动编号
- 使用 `scripts/merge.py`：
  - 按 `paper_output/tasks.json` 的顺序读取各微单元文件并合并。
  - 自动清理历史生成中可能残留的 `【摘要 | ABS-1】` 等过程标签。
  - 合并为一个 Markdown 文本，并执行：
    - 自动生成目录与章节编号（如“1 问题背景”“2 问题提出”）。
    - 图/表/公式/参考文献的统一编号（如“图1”“表2”“式(3)”与“[4]”）。
    - 交叉引用替换与检查，对“见第X章图Y”“见式(3)”等文字进行解析并保证对应目标存在。
  - **[New] 直接生成 Word (docx)**:
    - 脚本内部集成了 `python-docx` 库，在合并的同时直接写入 `.docx` 文件。
    - **不依赖 Pandoc**，无需安装额外软件即可生成。
    - 注意：数学公式将以 LaTeX 源码形式保留在 Word 中（如 `$E=mc^2$`），需用户使用 MathType 或 Word 自带工具渲染。
- 若发现断链或重复编号，`ref_check.md` 中会给出具体位置与建议修正方式。

### 5. 验收与调整
- 对生成完的 `final_paper.md`，本技能建议：
  - 先按章节快速检查：是否每一问都得到完整回答，是否有“只写方法不给结果”或“只给结果没有验证”的段落。
  - 对照 `C_评分点对齐表.md`：检查每个评分点至少在论文中出现一次对应的文字与图表。
  - 若发现某些部分字数明显不足或风格不一致，可回到对应微单元模板，放宽或调整字数与验收条件，再用 `generate_all.py` 局部重跑。

## 与其他技能的关系
- 与 `problem-doc-model-selector`：
  - 前者解决“题目看懂了、模型路线选好了”的问题；本技能基于这些结果完成大规模文字生成。
- 与章节规划类能力：
  - 章节规划负责确定论文大纲和小节逻辑；本技能进一步细化到“句级/段级微单元”，更适合需要精准控制字数与评分点覆盖的场景。
- 与 `paper-workflow-orchestrator`：
  - `paper-workflow-orchestrator` 从全流程角度串联“赛题解析→数据计算→占位符→微单元→合并”；本技能专注于其中“微单元生成与合并”这一段。
- 与 `paper-formal-writer`：
  - `paper-formal-writer` 负责正式论文范式、正式 outline、`final_paper_source.md` 写作约束、Word 排版和格式门禁；本技能只提供提示词资产、局部扩写和低能力模型兜底草稿。

## 防跑偏检查
- 不要跳过占位符字典填充就开始批量生成，否则生成内容会缺少具体数值或出现风格不统一的描述。
- 微单元模板中的验收条件应尽量与评分点对齐，避免“微单元写得很漂亮，但没有支撑比赛评分指标”。
- 若只想写一篇较短的说明性报告而非国赛级长文，可以减少微单元数量，或基于附录 A 的提示词调整拆分粒度，本技能依然适用。

## 何时不必使用本技能
- 仅需要补写少量段落或修订现有论文时，可直接在对应段落上局部生成，不必动用完整微单元系统。
- 任务是英文简短摘要或 PPT 文本等，粒度无需细到“句级微单元”时，本技能会显得过重。

## 附录 A：扩展材料（可选）
以下内容用于“更细粒度微单元/接入 LLM 生成”的扩展模式；当前离线脚本不会读取。

# CUMCM 论文分步生成提示词（超详细版）

本文件将论文拆成“章→节→段→句”四级，共 200+ 微单元，每单元给出：
- 角色设定
- 输入占位符
- 输出字数/格式
- 验收标准
- 交叉引用要求

可直接喂给 LLM 逐单元生成，最后自动合并。

---

## 0. 前置公共变量
请在整个写作过程中始终使用以下占位符，并在首次出现时替换为真实值（需在 `step3_filled_placeholder.py` 中定义）：

- {{论文题目}}
- {{背景关键词}}（如：光伏、交通流、碳排放、医疗资源）
- {{核心指标}}（如：厚度、效率、成本、相关系数）
- {{问题一模型}} / {{问题一算法}} / {{问题一结果}}
- {{问题二模型}} / {{问题二算法}} / {{问题二结果}}
- {{问题三模型}} / {{问题三算法}} / {{问题三结果}}
- {{主要软件}} = MATLAB / Python / SPSS / LINGO
- {{数据附件}} = 当前赛题附件说明

---

## 1. 摘要（≈800 字，6 段，48 句）

| 微单元编号 | 句序 | 角色 | 输入占位符 | 输出字数 | 验收标准 | 交叉引用 |
|------------|------|------|------------|----------|----------|----------|
| ABS-1-1 | 第1句 | 背景专家 | {{宏观背景}} | 15-20 | 包含{{背景关键词}}与应用领域 | 无 |
| ABS-1-2 | 第2句 | 背景专家 | {{行业痛点}} | 15-20 | 引用数据或现状说明问题的紧迫性 | 无 |
| ABS-1-3 | 第3句 | 背景专家 | {{研究价值}} | 15-20 | 明确本文方法的核心优势（如无损、高效、精准） | 无 |
| ABS-2-1 | 第4句 | 模型综述 | {{三问概述}} | 20-25 | 被动语态，概括全文解决的主要任务 | 无 |
| ABS-3-1 | 第5句 | 问题一专家 | {{问题一模型}} | 20-25 | 出现该模型的核心术语（如“规划”、“回归”、“微分方程”） | 见第1章式(1) |
| ABS-3-2 | 第6句 | 问题一专家 | {{问题一算法}} | 20-25 | 明确具体算法名称（如“遗传算法”、“最小二乘”） | 见第5章图3 |
| ABS-3-3 | 第7句 | 问题一专家 | {{问题一结果}} | 20-25 | 给出关键数值结果+单位 | 见第6章表2 |
| ABS-4-1 | 第8句 | 问题二专家 | {{问题二模型}} | 20-25 | 描述进阶模型的改进点 | 见第1章式(3) |
| ABS-4-2 | 第9句 | 问题二专家 | {{问题二算法}} | 20-25 | 提及求解策略或优化方法 | 见第5章算法2 |
| ABS-4-3 | 第10句| 问题二专家 | {{问题二结果}} | 20-25 | 给出核心指标的改善幅度或具体数值 | 见第6章表3 |
| … | … | … | … | … | … | … |
| ABS-6-4 | 第48句| 展望专家 | {{未来工作}} | 15-20 | 提出一种具体的可扩展方向 | 无 |

生成方法：
1. 逐句调用 LLM，替换占位符；
2. 每句自检：字数、关键词、被动语态；
3. 48 句完成后自动拼接成 1 段，再人工润色。

---

## 2. 问题重述（≈1500 字，2 节，12 段，96 句）

### 2.1 问题背景（≈400 字，4 段，32 句）

| 微单元 | 段内句 | 角色 | 输入 | 字数 | 验收 | 引用 |
|--------|--------|------|------|------|------|------|
| BG-1-1 | 1 | 宏观叙事 | {{宏观政策/趋势}} | 25-30 | 引用国家政策、行业白皮书或统计数据 | 政府文件 |
| BG-1-2 | 2 | 宏观叙事 | {{研究对象现状}} | 25-30 | 描述市场规模、发展趋势或社会影响 | 文献 [1] |
| BG-1-3 | 3 | 宏观叙事 | {{现有方法局限}} | 25-30 | 对比传统方法的不足（成本高/效率低/精度差） | 文献 [2] |
| … | … | … | … | … | … | … |
| BG-4-8 | 32 | 微观落脚 | {{具体任务目标}} | 25-30 | 明确题目要求的具体技术指标或决策目标 | 实验数据 |

### 2.2 问题提出（≈1100 字，8 段，64 句）

按“问题一/二/三”再细分，每问 3 段：（1）重述原文→（2）学术化转写→（3）可计算任务定义

例：

| 微单元 | 句 | 角色 | 输入 | 字数 | 验收 | 引用 |
|--------|----|------|------|------|------|------|
| PR1-1 | 1 | 原文引用 | 原题 Q1 一句 | ≤30 | 双引号+括号出处 | 题面 |
| PR1-2 | 2 | 学术转写 | “建立…模型”→“构建…定量框架” | 25-30 | 动词升级，将通俗语言转化为数学术语 | 无 |
| PR1-3 | 3 | 任务定义 | 输入：{{输入变量}}；输出：{{输出变量}} | 20-25 | 清晰定义I/O，使用符号列表 | 见符号表 |

…以下同理，共 96 句。

---

## 3. 问题分析（≈1000 字，3 节，24 段，192 句）

每问 8 段，每段 8 句，按“漏斗”逻辑：（1）本质判定→（2）数据特征→（3）模型动机→（4）算法理由→（5）指标选取→（6）验证方案→（7）难点预告→（8）小结

例（问题一第1段）：

| 微单元 | 句 | 角色 | 输入 | 字数 | 验收 | 引用 |
|--------|----|------|------|------|------|------|
| AN1-1-1 | 1 | 本质判定 | {{问题一数学本质}} | 20-25 | 判定为：优化/预测/分类/评价/机理 | 文献 [3] |
| AN1-1-2 | 2 | 本质判定 | {{关键理论依据}} | 20-25 | 提及核心公式或定理名称 | 式(1) |
| … | … | … | … | … | … | … |
| AN1-1-8 | 8 | 小结 | “综上，Q1 为{{任务类型}}任务” | 15-20 | 总结任务类型，承上启下 | 无 |

---

## 4. 模型假设（≈600 字，6 条，48 句）

每条假设拆 8 句：（1）必要性→（2）合理性→（3）简化范围→（4）影响评估→（5）数据支持→（6）反例排除→（7）文献佐证→（8）符号约定

例：假设1“{{假设1标题}}”

| 微单元 | 句 | 角色 | 输入 | 字数 | 验收 | 引用 |
|--------|----|------|------|------|------|------|
| AS1-1 | 1 | 必要性 | {{假设1内容}} | 15-20 | 用“为简化…”或“考虑到…”开头 | 无 |
| AS1-2 | 2 | 合理性 | {{假设1合理性依据}} | 15-20 | 给出数据统计特征或物理常识支撑 | 附件数据 |
| … | … | … | … | … | … | … |
| AS1-8 | 8 | 符号 | 用 {{相关符号}} 表示 | ≤15 | 与符号表定义一致 | 符号表 |

---

## 5. 符号说明（≈800 字，表格+清单，2 节，16 段，128 句）

### 5.1 符号定义表（自动脚本生成）

每行=1 句，共 N 行，每句格式：

| 微单元 | 句 | 角色 | 输入 | 字数 | 验收 | 引用 |
|--------|----|------|------|------|------|------|
| SYM-i | 1 | 表格行 | 符号、定义、单位 | 20-30 | LaTeX 格式正确，单位规范 | 无 |

### 5.2 纯文本对照清单（自动脚本生成）

每句格式：“汉字 --- 符号”

---

## 6. 模型建立与求解（≈3000 字，3 节，72 段，576 句）

每问 24 段，按“通用建模模板”拆：

### 6.1 问题一（基础模型，8 段，192 句）

| 段序 | 段主题 | 句数 | 微单元示例 | 验收要点 |
|------|--------|------|------------|----------|
| 1 | 机理/原理分析 | 24 | MD1-1-1~24 | 阐述变量间的逻辑或物理关系，引入{{核心变量}} |
| 2 | 数学推导/构建 | 24 | MD1-2-1~24 | 建立方程、目标函数或约束条件，推出核心公式 |
| 3 | 算法流程/策略 | 24 | MD1-3-1~24 | 描述求解步骤，给出流程图引用 |
| 4 | 核心求解过程 | 24 | MD1-4-1~24 | 展示关键代码逻辑或中间计算结果 |
| 5 | 优化/改进/联立 | 24 | MD1-5-1~24 | 处理复杂情况、多目标或参数调整 |
| 6 | 误差/不确定性 | 24 | MD1-6-1~24 | 分析误差来源或参数敏感性 |
| 7 | 结果展示 | 24 | MD1-7-1~24 | 呈现最终数值、表格或分类结果 |
| 8 | 小结 | 24 | MD1-8-1~24 | 回应问题一，重申核心结论 |

每句 15-25 字，共 192 句。

### 6.2 问题二（进阶/复杂模型，8 段，192 句）

同上结构，重点在于：
1. 模型的递进关系（基于Q1的改进或新场景适配）。
2. 更复杂的算法（如启发式算法、深度学习、非线性规划）。
3. 更深入的结果对比（改进前后效果对比）。

### 6.3 问题三（综合评价/推广/应用，8 段，192 句）

重点在于：
1. 建立评价指标体系（客观/主观权重）。
2. 多方案对比与排序（TOPSIS/AHP/DEA等）。
3. 模型的鲁棒性检验与灵敏度分析。
4. 实际应用建议或推广价值。

---

## 7. 结果分析与可视化（≈1500 字，3 节，24 段，192 句）

每问 8 段：

1. 主结果概括（一句话结论）
2. 详细数值表格展示
3. 误差分析/置信区间（误差棒图）
4. 方案对比/模型对比（柱状图/雷达图）
5. 变化趋势/规律发现（折线图/散点图）
6. 统计显著性检验（P值/R平方）
7. 业务/物理含义解释
8. 段落小结

---

## 8. 模型检验（≈1200 字，3 节，18 段，144 句）

每问 6 段：

1. 检验目的与方法选择
2. 数据集划分（训练/测试）或 实验设计
3. 交叉验证结果 / 对照组分析
4. 残差分布 / 误差正态性检验
5. 极端情景测试 / 压力测试
6. 检验结论（稳健性/适用性）

---

## 9. 结论与建议（≈800 字，3 节，12 段，96 句）

每问 4 段：

1. 直截了当回答原问（≤20 字）
2. 给出具体数值答案 + 置信水平/适用范围
3. 基于结果的业务/管理建议
4. 政策含义或社会价值

---

## 10. 不足与展望（≈600 字，2 段，48 句）

1. 不足 3 点（每点 8 句）：针对模型假设强、数据局限、算法复杂度的自我批评。
2. 展望 3 点（每点 8 句）：未来数据扩充、模型推广、算法优化的方向。

---

## 11. 参考文献（≈400 字，自动脚本）

按 GB/T 7714-2015 生成 10-15 条，每句 20-30 字。

---

## 12. 附录（≈2000 字，代码+图表）

### 12.1 核心代码（Python/MATLAB）

每函数 1 段，每段 16 句：功能说明→输入参数→输出结果→关键逻辑→注释→示例调用→结果截图→小结

### 12.2 附加图表

每图 1 段，每段 8 句：图题→坐标含义→颜色说明→图例解释→读图结论→与其他图对比→正文引用→文件路径

---

## 自动化脚本

提供脚本：
- 当前离线实现使用 `scripts/generate_all_offline.py`；若要接入真实大模型逐单元生成，可按下面 JSON 结构扩展新的 `generate_micro_unit.py`。

运行后得到：

```json
{
  "unit_id": "ABS-1-1",
  "text": "本文针对{{行业/领域}}中的{{核心问题}}，通过建立{{模型名称}}，利用{{算法名称}}，解决了{{具体难点}}，对{{应用价值}}具有重要的指导意义。",
  "pass": true,
  "msg": ""
}
```

---

## 合并流程

1. 按编号顺序读取所有微单元 JSON；
2. 过滤 `pass=false` 的单元，给出重跑提示；
3. 按“章-节-段-句”层级拼接成 `.md` 文件；
4. 自动编号：图/表/式/参考文献；
5. 生成交叉引用索引，替换“见第X章图Y”为实际编号；
6. 输出：
   - `final_paper.md`（完整论文）
   - `unit_log.json`（每单元校验日志）
   - `ref_check.md`（引用断链报告）

---

## 使用步骤

1. 先调用 `quality-assurance-auditor`，生成 `paper_output/tasks.json`；
2. 如需具体数值与模型名，填写 `step3_filled_placeholder.py`（可选）；
3. 运行 `python .agents/skills/paper-micro-unit-generator/scripts/generate_all_offline.py` 生成 `paper_output/micro_units/*.txt`；
4. 运行 `python .agents/skills/paper-micro-unit-generator/scripts/merge.py` 生成 `paper_output/final_paper.md`；
5. 最后用 `quality-assurance-auditor` 对全文做一致性与评分点审计（可选但推荐）。

---

## 扩展说明

- 新增微单元：在对应表格续行，保证编号连续；
- 调整字数：修改“字数”列，脚本自动截断或提示扩写；
- 切换语言：把模板中文换成英文即可输出英文论文；
- 插入图表：在对应微单元模板用 `![图题](path)` 占位，合并脚本自动编号。

---

> 本提示词共拆出 **≈2000 个微单元**，总字数 **≈1.5 万中文字**，可直接生成 **国赛一等奖篇幅与深度** 的完整论文。

## 附录 B：合并脚本

提供脚本：
- `scripts/merge.py`
