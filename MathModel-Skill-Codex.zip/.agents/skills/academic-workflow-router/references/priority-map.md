# Academic Skill Priority Map

Use this map only after identifying the requested deliverable. “Support” means add it when its input is available; it does not authorize parallel end-to-end generation.

```mermaid
flowchart TD
    A["Academic request"] --> B{"Primary deliverable?"}
    B -->|"Mathematical-modeling contest"| C{"Stage?"}
    C -->|"Compare topics/routes"| C1["math-modeling-contest-route-selection"]
    C -->|"Solve full problem"| C2["mathmodel-skill"]
    C -->|"Verify results"| C3["neoxue-math-modeling-solver"]
    C -->|"Write contest paper"| C4["math-modeling-paper"]
    C2 --> C3 --> CF["math-modeling-figure-engineer\n+scipilot-figure-skill for chart choice/QA"]
    CF --> C4

    B -->|"Scientific manuscript"| D["nature-writing"]
    D --> DE["nature-academic-search / nature-ref-verifier"]
    D --> DF["nature-figure / nature-statistics"]
    DE --> DG["nature-polishing"]
    DF --> DG --> DH["nature-reviewer"]

    B -->|"Paper reading / literature"| E{"Scope?"}
    E -->|"One paper"| E1["nature-reader or nature-paper-card"]
    E -->|"Batch discovery"| E2["nature-literature-pipeline"]
    E -->|"Reference verification"| E3["nature-ref-verifier"]

    B -->|"Proposal or report"| F{"Research-led?"}
    F -->|"Proposal / research plan"| F1["researchwrite\n(package: nature-proposal-writer)"]
    F -->|"Template-led manual/report"| F2["documents:documents"]

    B -->|"Academic PPT"| G{"Input format?"}
    G -->|"Paper, notes, figures"| G1["nature-paper2ppt"]
    G -->|"Image/scanned existing deck"| G2["nature-image2ppt → presentations:Presentations"]

    B -->|"Standalone data figure"| H{"Context?"}
    H -->|"Model output"| H1["math-modeling-figure-engineer\n+scipilot-figure-skill for chart choice/QA"]
    H -->|"Manuscript figure"| H2["nature-figure\n+after scipilot-figure-skill"]
    H -->|"Exploratory chart choice"| H3["scipilot-figure-skill"]
```

| Request / state | Primary Skill | Serial supporting Skills | Do not combine or skip |
|---|---|---|---|
| CUMCM/MCM topic selection | `math-modeling-contest-route-selection` | `mathmodel-skill` after a topic is chosen | Do not choose from a generic model list alone |
| Full modeling contest solution | `mathmodel-skill` | `neoxue-math-modeling-solver` → `math-modeling-figure-engineer` (with `scipilot-figure-skill`) → `math-modeling-paper` | Do not run another end-to-end modeling controller in parallel |
| Modeling figures | `math-modeling-figure-engineer` | `scipilot-figure-skill` for data inspection/chart choice/QA; `nature-figure` for manuscript composition/export; `intelligrapher` for supported domain templates | Do not plot unverified results or use decorative charts as validation |
| Scientific manuscript | `nature-writing` | `nature-academic-search` / `nature-ref-verifier`; `nature-figure` / `nature-statistics`; `nature-polishing` → `nature-reviewer` | Do not cite unverified references or polish unsupported claims |
| Citation or data statement | `nature-ref-verifier` / `nature-citation`; `nature-data` for data availability | `nature-writing` after evidence is verified | Do not add generated references directly to the final manuscript |
| One paper reading | `nature-reader` or `nature-paper-card` | `nature-ref-verifier` when bibliographic accuracy matters | Do not replace full bilingual reading with a summary unless requested |
| Literature discovery | `nature-literature-pipeline` | `nature-academic-search`, then `nature-ref-verifier` for used references | Do not treat search snippets as verified source data |
| Research proposal / opening report | `researchwrite` (package: `nature-proposal-writer`) | `nature-academic-search`, `nature-statistics`, `nature-figure` as evidence requires | Do not override the institution's required template |
| Professional manual or competition report | `documents:documents` when output/template is DOCX; `article-writing` only for template-free narrative guides | `nature-writing` only when the work is research/publication-oriented | Do not impose Nature style on a required template |
| Academic PPT from content | `nature-paper2ppt` | `nature-figure` if a source figure needs revision | Do not use `nature-image2ppt` for a newly authored deck |
| Existing image/scanned PPT reconstruction | `nature-image2ppt` | `presentations:Presentations` only for subsequent edits | Do not treat reconstruction as fresh content authoring |

## Acceptance scenarios

| Example request | Expected primary | Expected first serial handoff |
|---|---|---|
| “比较国赛 A/B/C 题，推荐一题” | `math-modeling-contest-route-selection` | `mathmodel-skill` only after the selection |
| “解这道国赛题并画验证图” | `mathmodel-skill` | `neoxue-math-modeling-solver` → `math-modeling-figure-engineer` → `math-modeling-paper` |
| “润色这段英文科研论文 Results” | `nature-polishing` | `nature-statistics` only if statistical claims need review |
| “核验这份参考文献” | `nature-ref-verifier` | `nature-citation` only after verified records exist |
| “把这篇论文做成组会 PPT” | `nature-paper2ppt` | `nature-figure` only for required figure revision |
| “按竞赛模板写技术说明书” | `documents:documents` | `article-writing` only for a template-free narrative; `nature-writing` only when explicitly research-style |
