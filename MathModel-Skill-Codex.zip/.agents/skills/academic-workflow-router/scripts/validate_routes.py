#!/usr/bin/env python3
"""Validate the router's required Skill references and acceptance examples."""

from __future__ import annotations

from pathlib import Path
import sys


SKILL_ROOT = Path(__file__).resolve().parents[1]
SKILLS_ROOT = SKILL_ROOT.parent
MAP_PATH = SKILL_ROOT / "references" / "priority-map.md"

REQUIRED_GLOBAL_SKILLS = (
    "math-modeling-contest-route-selection",
    "mathmodel-skill",
    "neoxue-math-modeling-solver",
    "math-modeling-paper",
    "math-modeling-figure-engineer",
    "scipilot-figure-skill",
    "intelligrapher",
    "nature-writing",
    "nature-academic-search",
    "nature-ref-verifier",
    "nature-figure",
    "nature-statistics",
    "nature-polishing",
    "nature-reviewer",
    "nature-reader",
    "nature-paper-card",
    "nature-literature-pipeline",
    "nature-citation",
    "nature-data",
    "nature-proposal-writer",
    "nature-paper2ppt",
    "nature-image2ppt",
)

ACCEPTANCE_EXAMPLES = (
    "比较国赛 A/B/C 题，推荐一题",
    "解这道国赛题并画验证图",
    "润色这段英文科研论文 Results",
    "核验这份参考文献",
    "把这篇论文做成组会 PPT",
    "按竞赛模板写技术说明书",
)

REQUIRED_ROUTE_FRAGMENTS = (
    "`neoxue-math-modeling-solver` → `math-modeling-figure-engineer` (with `scipilot-figure-skill`) → `math-modeling-paper`",
    "| “按竞赛模板写技术说明书” | `documents:documents` |",
)


def main() -> int:
    content = MAP_PATH.read_text(encoding="utf-8")
    failures = []
    if "```mermaid" not in content:
        failures.append("priority map has no Mermaid diagram")
    for name in REQUIRED_GLOBAL_SKILLS:
        if not (SKILLS_ROOT / name / "SKILL.md").is_file():
            failures.append(f"required Skill missing: {name}")
    for example in ACCEPTANCE_EXAMPLES:
        if example not in content:
            failures.append(f"acceptance example missing: {example}")
    for fragment in REQUIRED_ROUTE_FRAGMENTS:
        if fragment not in content:
            failures.append(f"required route missing: {fragment}")
    if failures:
        print("Router validation failed:", *failures, sep="\n- ")
        return 1
    print(
        "Router validation passed: "
        f"{len(REQUIRED_GLOBAL_SKILLS)} Skills, "
        f"{len(ACCEPTANCE_EXAMPLES)} examples, "
        f"{len(REQUIRED_ROUTE_FRAGMENTS)} route guards"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
