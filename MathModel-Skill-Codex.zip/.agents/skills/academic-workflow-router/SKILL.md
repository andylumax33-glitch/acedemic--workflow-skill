---
name: academic-workflow-router
description: Route mathematical-modeling contests, scientific papers, professional reports, literature work, figures, and academic PPT tasks to the installed primary and supporting Skills. Use whenever a request could match multiple academic workflow Skills or needs a coherent end-to-end sequence.
---

# Academic Workflow Router

Classify the request before starting substantive work. Choose **one** primary Skill, then add only the supporting Skills whose entry conditions are satisfied. Do not start multiple end-to-end workflows for one deliverable.

## Routing procedure

1. Identify the deliverable and its governing constraint: mathematical-modeling contest, scientific manuscript, proposal/report, literature task, figure, or PPT.
2. Read [priority-map.md](references/priority-map.md) and select the matching primary Skill.
3. State the primary Skill and any immediately applicable supporting Skill in the first progress update. Keep supporting work serial: results and figures must exist before formal writing; verified references must exist before citation insertion.
4. Follow the primary Skill's instructions. Use the reference map only to resolve overlaps or handoffs.

## Priority rules

- Mathematical-modeling contests are contest-first: use the modeling workflow and official template/rules as the authority. Nature Skills may assist verified figures, literature, statistics, English polishing, or review, but never replace contest requirements.
- Scientific manuscripts and academic presentation decks are Nature-first unless the user supplies a different journal, venue, or template.
- For generic professional reports or competition manuals, follow the supplied template first. Use Nature writing only when the work is explicitly research-oriented or publication-style.
- `nature-shared` is an internal dependency only, never a user-facing primary Skill.

## Non-negotiable handoffs

- Do not draft a formal modeling paper from unverified numbers, figures, or citations.
- Do not use both `mathmodel-skill`, `ez-math-model`, or `math-modeling` as parallel end-to-end controllers. Choose one; the current CUMCM project defaults to `mathmodel-skill`.
- Use `nature-image2ppt` only to reconstruct an existing image-based PPT/PDF, not to author a new academic deck.
- For data figures, use `scipilot-figure-skill` to profile data, choose a chart, and complete visual QA. Use `nature-figure` for manuscript-level composition/export after that chart specification is approved.
- For a template-led DOCX report or manual, use `documents:documents`; reserve `article-writing` for template-free narrative guides or long-form copy.
- The proposal Skill is invoked as `researchwrite` (installed package directory: `nature-proposal-writer`).
- If the user explicitly names a Skill, honor it unless it conflicts with contest rules, supplied templates, evidence requirements, or a necessary prerequisite; explain the conflict and select the nearest compatible workflow.
